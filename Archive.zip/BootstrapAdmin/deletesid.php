
<?php
session_start();
          if(isset($_POST['remember'])){
              setcookie("username",$username);
          }

//if(isset($_POST['submit'])){
    $host="localhost";//host name 
    $username="root"; //database username 
    $word="";//database word  
    $db_name="eyevee";//database name  
    $con=mysqli_connect("$host", "$username", "$word","$db_name");//connection string 

if($con!=TRUE){
    echo "Error1: ".mysqli_error($con)."<br>"; 
}
   // $industry=$_SESSION['industry'];
//$description=$_SESSION['description'];
    $studentid=$_POST['sid'];
  
   $sql = "DELETE FROM studentdetails WHERE studentid='$studentid' ";

if (mysqli_query($con, $sql)) {
    echo "Record deleted successfully";
     header( "refresh:0;url=idform.php" );
} else {
    echo "Error deleting record: " . mysqli_error($con);
}

mysqli_close($con);


?>