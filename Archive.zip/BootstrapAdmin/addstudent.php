<?php
session_start();
          if(isset($_POST['remember'])){
              setcookie("username",$username);
          }

if(isset($_POST['submit'])){
    $host="localhost";//host name 
    $username="root"; //database username 
    $word="";//database word  
    $db_name="eyevee";//database name  
    $con=mysqli_connect("$host", "$username", "$word","$db_name");//connection string 


if($con!=TRUE){
    echo "Error1: ".mysqli_error($con)."<br>"; 
    
    echo "eroorrrrr";
}
        
if(!empty($_POST['studentid'])) {


$studentid=$_POST['studentid'];
$studentname=$_POST['studentname'];
    
$serialnumberbooking= $_SESSION['sss'];
$name=$_SESSION['name'];    
       
$offerbyindustry= $_SESSION['offeruploadedbyindustry']; 
  
$bookingid=$_SESSION['bookingidnum'];  
  
$institutionname=$_SESSION['institutionname']; 
    
$query="insert into studentdetails(bookingid,institutionname,studentid,studentname,appliedby,forindustry,industryserialnumber) values('".$bookingid."','".$institutionname."','".$studentid."','".$studentname."','".$name."','".$offerbyindustry."','".$serialnumberbooking."')";
$result=mysqli_query($con,$query);  
    
       
if($result!=true){
    echo "Error2: ".mysqli_error($con)."<br>"; 
}
else
{
  header("refresh:0;url=idform.php" );
    
    
      }

    }
}

?>
  
 


 
