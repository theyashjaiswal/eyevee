<?php
$con= mysqli_connect("localhost", "root","","eyevee");


if(isset($_GET['bookingid']) && !empty($_GET['bookingid']) AND isset($_GET['otp']) && !empty($_GET['otp']))
{
    $bookingid = $_GET['bookingid'];
    $otp =$_GET['otp'];

$search = "SELECT bookingid,otp,emailconfirmationstatus FROM confirmationstatus WHERE bookingid='".$bookingid."' AND otp='".$otp."' AND emailconfirmationstatus='0'";
$match  =mysqli_query($con,$search);
//if($match > 0){
 $query="UPDATE confirmationstatus SET emailconfirmationstatus='1' WHERE bookingid='".$bookingid."' AND otp='".$otp."' AND emailconfirmationstatus='0' ";
 $result=mysqli_query($con,$query); 
       
echo "<script>alert('Verified Successfully!!'); window.location='../index.html'; </script>";    
//}
    
}

else

{
    
   echo "<script>alert('Invalid URL!!!'); window.location='Bootstrap Admin/Login.html'; </script>";  
  
}

 echo '<div class="statusmsg">Invalid approach, please use the link that has been send to your email.</div>';

?>
