<?php
session_start();

 if(empty($_SESSION['name']))
    {
        // If they are not, redirect them to the login page.
        header("Location:login.html");
        
        // Remember that this die statement is absolutely critical.  Without it,
        // people can view your members-only content without logging in.
       // die("Redirecting to login.php");
    }
$con= mysqli_connect("localhost", "root","","eyevee");
if($con!=TRUE){
echo "Error1: ".mysql_error()."<br>";
} 
$mobileno=$_SESSION['mobileno'];
$bookingid=$_SESSION['bookingidnumber'];
$_SESSION['bookingidtiredbro']=$bookingid;



$query="SELECT otp from confirmationstatus WHERE bookingid='$bookingid' AND otpconfirmationstatus='0' ";
$result=mysqli_query($con,$query); 
$results=mysqli_fetch_array($result);
$otp=$results['otp'];

if($otp==$_POST['otp'] )
{
$enteredotp = $_POST['otp']; // Set OTP


$query="UPDATE confirmationstatus SET otpconfirmationstatus='1' WHERE bookingid='$bookingid' AND  otpconfirmationstatus='0' ";
$result=mysqli_query($con,$query); 
    

   // header('location:Login.html');
    echo "<script>alert('OTP VERIFIED'); window.location = 'pdfgenerator.php'; </script>";
}
else{
echo "<script>alert('INVALID OTP!!!');
   window.location = 'otpconfirmation.php';
</script>";
}
?>
