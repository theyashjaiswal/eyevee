<?php
session_start();
         
 if(empty($_SESSION['name']))
    {
        // If they are not, redirect them to the login page.
        header("Location:login.html");
        
        // Remember that this die statement is absolutely critical.  Without it,
        // people can view your members-only content without logging in.
       // die("Redirecting to login.php");
    }

if(isset($_POST['submit'])){
    $host="localhost";//host name 
    $username="root"; //database username 
    $word="";//database word  
    $db_name="eyevee";//database name  
    $con=mysqli_connect("$host", "$username", "$word","$db_name");//connection string 


if($con!=TRUE){
    echo "Error1: ".mysqli_error($con)."<br>"; 
}
        
if(!empty($_POST['branch'])) {
$username=$_SESSION['name'];
$industry=$_POST['industry'];
$category=$_POST['category'];
    $statelocation=$_POST['statelocation'];
    $districtlocation=$_POST['districtlocation'];
    $city=$_POST['city'];
$description=$_POST['description'];
    $fromdate=$_POST['fromdate'];
    $todate=$_POST['todate'];
$checkbox1=$_POST['branch'];  
$value1="";  
    $value= " ";
foreach($checkbox1 as $value1) {
    $value .=$value1.",";
}
$query="insert into industry(username,industry,category,statelocation,districtlocation,city,description,fromdate,todate,branch) values('".$username."','".$industry."','".$category."','".$statelocation."','".$districtlocation."','".$city."','".$description."','".$fromdate."','".$todate."','".$value."')";
$result=mysqli_query($con,$query); 

if($result!=true){
    echo "Error2: ".mysqli_error($con)."<br>"; 
}
else
{
  header( "refresh:0;url=indusdashboard.php" );
    
    
      }

    }
}

?>
  
 


 
