
<?php
$con= mysqli_connect("localhost", "root","","eyevee"); 
if($con!=TRUE){
echo "Error1: <br>";
}
if(isset($_COOKIE['username']))
{ 
$username=$_COOKIE['username'];
$query="select * from login where Username='".$username."'"; 
}
else
{
$username=$_POST['username']; 
$password=$_POST['password'];
//$en_cr=sha1($password);
$query="select * from login where Username='".$username."' and Password='".$password."' and active='1'";

}

$result=mysqli_query($con,$query); 
//$result2=mysqli_query($con,$accountquery); 

if($result!=true)
{
echo "Error2: <br>"; 
}

$records= mysqli_num_rows($result);

if($records!=0)
{
// $rec=mysql_fetch_row($result); 
session_start(); 
if(isset($_POST['remember'])){
setcookie("username",$username); 
}
echo "Login Successfull<br>";
$_SESSION['name']=$username;
$results=mysqli_fetch_array($result);
$_SESSION['accounttype']=$results['accounttype'];

if($_SESSION['accounttype']=='Institution')
    
{
header('location:BootstrapAdmin/instdashboard.php');
}
   
else if($_SESSION['accounttype']=='Industry')
    { 
        header('location:BootstrapAdmin/indusdashboard.php');
    }
if($_SESSION['accounttype']=='Admin')
{
    
    header('location:BootstrapAdmin/admindashboard.php');
    
}

/*echo "Welcome ".$username." !! <br><br>";

echo "Change Password <a href=\"pass.php\">Click Here!</a>";
echo '<br><br>&nbsp;&nbsp;&nbsp;<input type="button" value="Logout" onclick="window.location=\'Login.php?set=true\'">';*/
} 
else{
echo "<script>alert('VERIFICATION PENDING!! or Invalid Credentials!!'); window.location='BootstrapAdmin/Login.html'; </script>";
echo "Invalid Username or Password <br>";
} ?>
